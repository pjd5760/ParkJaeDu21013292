close
clear
clc

load nav.mat
BDS_a = (nav.BDS.a) / 10^3;         %semi-major axis[km]                                      
BDS_e = nav.BDS.e;                  %eccentricity                                                                 
BDS_i = nav.BDS.i*180/pi;           %inclination                              
BDS_arg = nav.BDS.omega*180/pi;     %argument of perigee
BDS_p = BDS_a * (1- BDS_e^2);       %perigee 
BDS_RAAN = nav.BDS.OMEGA*180/pi;    %RAAN    
BDS_M0 = nav.BDS.M0;                %mean anomaly at t[rad]                                        
BDS_t = zeros(1440,6);              %apoch

for i=0:1:1440
    nu(i+1) = true_anomaly(BDS_a, BDS_e, [0 0 0 0 i 0], nav.BDS.toc, BDS_M0);       %[rad]
    BDS_t(i+1,:) = nav.BDS.toc+[0 0 0 0 i 0];
end

BDS_ENU=[0 0 0];

%ground station
lat=37;             %latitude[deg]
long=127;           %longitude[deg]
h=1;                %height[km]
el_mask=10;         %[deg]

BDS_rangeInPQW = zeros(3,1440);
BDS_velocityInPQW = zeros(3,1440);

%24hour in min
for t=1:1:1441
    %PQW range & velocity
    BDS_rangeInPQW(:,t) = solvRangeInPerifocalFrame(BDS_a, BDS_e, nu(t)*180/pi);
    BDS_velocityInPQW(:,t) = solveVelocityInPerifocalFrame(BDS_a, BDS_e, nu(t)*180/pi);
end

    %PQW 2 ECI
    BDS_ECI = PQW2ECI(BDS_arg, BDS_i, BDS_RAAN);
    BDS_rangeInECI=BDS_ECI*BDS_rangeInPQW;
    BDS_velocityInECI=BDS_ECI*BDS_velocityInPQW;
    
    %ECI 2 ECEF
    BDS_rangeInECEF = zeros(3,1440);
    BDS_velocityInECEF = zeros(3,1440);
    for t=1:1:1441
        DCM=ECI2ECEF_DCM(BDS_t(t,:)); 
        BDS_rangeInECEF(:,t)=DCM*BDS_rangeInECI(:,t); 
        BDS_velocityInECEF(:,t)=DCM*BDS_velocityInECI(:,t);
    end
    
    %ECEF 2 geodetic
    wgs84 = wgs84Ellipsoid('kilometer');
    for t=1:1:1441
        [lat(t), long(t), h(t)]= ecef2geodetic(wgs84, BDS_rangeInECEF(1,t),BDS_rangeInECEF(2,t),BDS_rangeInECEF(3,t));
        %ENU -> Az & El
%         [BDS_east(t), BDS_north(t), BDS_up(t)]=ecef2enu(BDS_rangeInECEF(1,t), BDS_rangeInECEF(2,t), BDS_rangeInECEF(3,t),lat,lon,h);
%         BDS_ENU=[BDS_east(t), BDS_north(t), BDS_up(t)];
%         BDS_az(t)=azimuth(BDS_ENU);                     %[deg]
%         BDS_el(t)=elevation(BDS_ENU, el_mask);          %[deg]
    end

% ground track
figure(1)
geoplot(lat, long,'y.')
geolimits([-90 90],[-180 180]) %earth angular rate 
legend('BDS')

% skyplot
% figure(2)
% skyplot(BDS_az, BDS_el)
% legend('BDS')

%satellite orbit
% flighttime=BDS_toc+days(1);
% sampleTime=60; %seconds
% sc_BDS = satelliteScenario(BDS_toc,stopTime_BDS,sampleTime);
% gs = groundStation(sc_BDS,lat,lon);
% sat = satellite(sc_BDS,BDS_a,BDS_e,BDS_i, ...
%         BDS_RAAN,BDS_arg,nu);
% ac = access(sat,gs);
% intvls = accessIntervals(ac);
% play(sc_BDS)
figure(2);
plot3(BDS_rangeInECI(1,:),BDS_rangeInECI(2,:),BDS_rangeInECI(3,:))